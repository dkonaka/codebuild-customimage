# eks-php

This is a sample PHP application for EKS CI/CD.
